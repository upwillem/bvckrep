in de websocket map moet de websocket staan
in de webserver map moet de webserver staan