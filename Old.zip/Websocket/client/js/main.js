// Compatibility shim
navigator.getUserMedia = navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia;


// PeerJS object
var peer = new Peer({ key: 'nydna3vyls9ssjor', debug: 3, config: {'iceServers': [
	{ url: 'stun:stun.l.google.com:19302' } // Pass in optional STUN and TURN server for maximum network compatibility
	]}});

//Connectie openen met peerserver
peer.on('open', function(id){
	console.log(peer.id); //log eigen connectieID
});

peer.on('call', function(call){
	call.answer(window.localStream); // beantwoord automatisch			TODO: acceptatie oproep
	step3(call);
});

//Error meldingen weergeven	
peer.on('error', function(err){
	alert(err.message);
	//step2();
});

//Click handlers setup
$(function(){
	$('#DoeBellen').click(function(){
		var clientId= document.getElementById('tbClientID').value;
		console.log('clientId = '+ clientId);
		var call = peer.call(clientId, window.localStream);
		
		step3(call);
	});
	step1();
	
	//TODO Hier zou endcall komen
});

function step1 () {
      // Get audio/video stream
	  navigator.getUserMedia = navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia;
	  
	  if (navigator.getUserMedia) {
	   navigator.getUserMedia (

		  //constraints
		  {
			 video: true,
			 audio: true
		  },

		  //successCallback
		  function(stream) {
			  
			var video = document.getElementById('MyVideo');
			video.src = window.URL.createObjectURL(stream);
			video.play();			 

			window.localStream = stream;
		  },

		  //errorCallback
		  function(err) {
			 alert("The following error occured: " + err);
		  }
	   );
	  } else {
		 alert("getUserMedia not supported for this browser");
	  }	  
	  
      
    };

function step3(call){
	// Wait for stream on the call, then set peer video display
      call.on('stream', function(stream){
        var video2 = document.getElementById('TheirVideo');
		video2.src = window.URL.createObjectURL(stream);
		video2.play();
		
		
		
		//$('#TheirVideo').prop('src', URL.createObjectURL(stream));
      });
	  
	  
};




//wachten tot DOM klaar is met laden alvorens streams en calls te doen.
// $(function(){
	// $('#DoeBellen').click(function(){
		//Initiate a call
		// var call = peer.call($('#tbClientID').val(), window.localstream);
		// call.on('stream', function(stream){
		// $('#TheirVideo').prop('src', URL.createObjectURL(stream));
		// });
	// }); 
  

  // navigator.getUserMedia = navigator.getUserMedia ||
                           // navigator.webkitGetUserMedia ||
                           // navigator.mozGetUserMedia ||
                           // navigator.msGetUserMedia;

  // window.URL = window.URL || window.webkitURL || window.mozURL || window.msURL;

  // if (navigator.getUserMedia) {
   // navigator.getUserMedia (

      //constraints
      // {
         // video: true,
         // audio: true
      // },

      //successCallback
      // function(localMediaStream) {
         // var video = document.getElementById('MyVideo');
         // video.src = window.URL.createObjectURL(localMediaStream);
         // video.play();
      // },

      //errorCallback
      // function(err) {
         // alert("The following error occured: " + err);
      // }
   // );
  // } else {
     // alert("getUserMedia not supported for this browser");
  // }
// });
