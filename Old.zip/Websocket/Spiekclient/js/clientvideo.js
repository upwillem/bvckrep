window.onload = function ()
{
  var stream;
  var video = document.getElementById("videoElement");

  navigator.getUserMedia = navigator.getUserMedia ||
                           navigator.webkitGetUserMedia ||
                           navigator.mozGetUserMedia ||
                           navigator.msGetUserMedia;

  window.URL = window.URL || window.webkitURL || window.mozURL || window.msURL;

  if (navigator.getUserMedia) {
   navigator.getUserMedia (

      // constraints
      {
         video: true,
         audio: true
      },

      // successCallback
      function(localMediaStream) {
         var video = document.querySelector('video');
         video.src = window.URL.createObjectURL(localMediaStream);
         video.play();
      },

      // errorCallback
      function(err) {
         alert("The following error occured: " + err);
      }
   );
  } else {
     alert("getUserMedia not supported for this browser");
  }
}
