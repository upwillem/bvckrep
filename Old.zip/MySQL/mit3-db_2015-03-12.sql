-- phpMyAdmin SQL Dump
-- version 4.1.9
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 12, 2015 at 11:25 AM
-- Server version: 5.5.36
-- PHP Version: 5.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mit3`
--

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(40) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES
('d5fb4a376a9b11ea1b07bfecd074fc9fd97638e7', '::1', 1425908392, ''),
('e4e50bb6f45a925f93a7eef769693782ff709d99', '10.77.133.103', 1425906799, ''),
('3f0bd91f8947ff7a7b5839c203a618613b2d787c', '10.77.145.75', 1425906765, ''),
('5fc9f758a6bcfdc5a78bd1aff221265d54784199', '::1', 1426021022, ''),
('6279a3a961a040b28cc664dac550727b7576c45e', '::1', 1426153423, ''),
('82b85f4581f3b589a672c1f2f9059ce2dd326629', '::1', 1426159347, '');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(60) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(128) NOT NULL,
  `type` enum('parent','child') NOT NULL DEFAULT 'child',
  `time_created` int(11) NOT NULL,
  `time_updated` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `parent_id`, `name`, `email`, `password`, `type`, `time_created`, `time_updated`) VALUES
(1, 0, 'Roel Larik', '1236830larik@zuyd.nl', '0eef698fdee888f274fcddcca378bef0e40d1e4131a8fe20420c067d13369983c4c08af46b2d375bc856cd01ba05acd8ef498310b51601412bc8d0ba1add4bd4', 'parent', 1425906548, 1425906548);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
