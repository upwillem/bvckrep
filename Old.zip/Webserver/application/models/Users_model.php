<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Users model
 *
 * @package     MIT3 BKVK
 * @subpackage  Models
 * @author      Roel Larik
 */

class Users_model extends CI_Model {
    
    /**
     * Adds a new user to the database.
     * 
     * @param array $data
     */
    public function add_user($data = array())
    {
        // Add to the database.
        $this->db->insert('users', $data);
    }
    
    /**
     * Returns whether the given credentials
     * are correct.
     * 
     * @param string $email
     * @param string $password
     * @return boolean
     */
    public function is_user($email = '', $password = '')
    {
        // Prepare the query.
        $this->db->from('users');
        $this->db->where('email', $email);
        $this->db->where('password', $password);
        $this->db->limit(1);
        
        // Execute the query.
        $query = $this->db->get();
        
        // Return the result.
        return ($query->num_rows() == 1);
    }
    
	public function get_user_id($email = '')
	{
		$this->db->from('users');
		$this->db->where('email', $email);
		
		$query = $this->db->get();
		
		return $query->row()->id;
	}
	
	public function get_user_type($email = '')
	{
		$this->db->from('users');
		$this->db->where('email', $email);
		
		$query = $this->db->get();
		
		return $query->row()->type;
	}
	
	public function get_user_name($id = '')
	{
		$this->db->from('users');
		$this->db->where('id', $id);
		
		$query = $this->db->get();
		
		return $query->row()->name;
	}
}