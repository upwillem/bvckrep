<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Template library
 *
 * @package     MIT3 BKVK
 * @subpackage  Libraries
 * @author      Roel Larik
 */

class Template_lib {
    
    /**
     * CodeIgniter instance
     * 
     * @var resource 
     */
    protected $CI;
    
    /**
     * Class's constructor.
     */
    public function __construct()
    {
        $this->CI =& get_instance();
    }
    
    /**
     * Displays a view inside the layout.
     * 
     * @param str $view
     * @param arr $data
     */
    public function render($view = '', $data = array())
    {
        $this->render_header();
        $this->render_content($view, $data);
        $this->render_footer();
    }
    
    /**
     * Displays a view without layout.
     * 
     * @param str $view
     * @param arr $data
     */
    public function render_partial($view = '', $data = array())
    {
        $this->render_content($view, $data);
    }
    
    /**
     * Displays the header view.
     * 
     * @return view
     */
    private function render_header()
    {
        $this->CI->load->view('template/header');
    }
    
    /**
     * Displays the requested view.
     * 
     * @param str $view
     * @param arr $data
     * @return view
     */
    private function render_content($view = '', $data = array())
    {
        $this->CI->load->view('content/' . $view, $data);
    }
    
    /**
     * Displays the footer view.
     * 
     * @return view
     */
    private function render_footer()
    {
        $this->CI->load->view('template/footer');
    }
    
}