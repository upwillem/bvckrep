<h1>Welkom <?php echo $name ?> !</h1>
<?php if($type == "parent"){ ?>
	<p><a href="<?php echo site_url('registerchild'); ?>" class="btn btn-lg btn-block">Voeg sub-account toe</a></p>
<?php } else { ?>
	<p>Hier kun je straks chatten!</p>
<?php } ?>