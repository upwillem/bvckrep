<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Register controller
 *
 * @package     MIT3 BKVK
 * @subpackage  Controllers
 * @author      Roel Larik
 */

class Register extends CI_Controller {
    
    /**
     * Class's constructor.
     * 
     */
    public function __construct()
    {
        // Extend the CI_Controller constructor.
        parent::__construct();
        
        // Load the required libraries.
        $this->load->library([
            'form_validation'
        ]);
        
        // Load the models needed.
        $this->load->model([
            'users_model'
        ]);
    }
    
    /**
     * Default registration view.
     * 
     * @return view
     */
    public function index()
    {
        $this->template_lib->render_partial('register');
    }
    
    /**
     * Processing the login request.
     * 
     * @return view
     */
    public function process()
    {
        // Set validation rules.
        $this->form_validation->set_rules('email', 'E-mail adres', 'required|valid_email|is_unique[users.email]', [
            'required' => 'Vul uw e-mail adres in.',
            'is_unique' => 'Dit e-mail adres is reeds in gebruik.',
            'valid_email' => 'Dit is geen geldig e-mail adres.'
        ]);
        $this->form_validation->set_rules('password', 'Wachtwoord', 'required', [
            'required' => 'Vul uw wachtwoord in.'
        ]);
        $this->form_validation->set_rules('password_confirm', 'Wachtwoord bevestigen', 'required|matches[password]', [
            'required' => 'Bevestig uw wachtwoord.',
            'matches' => 'De beide wachtwoorden komen niet overeen.'
        ]);
        $this->form_validation->set_rules('name', 'Weergave naam', 'required|is_unique[users.name]', [
            'required' => 'Vul uw gewenste weergave naam in.',
            'is_unique' => 'Deze weergave naam is reeds in gebruik.'
        ]);
        
        // Custom error delimiter.
        $this->form_validation->set_error_delimiters('<li>', '</li>');
        
        // Perform validation!
        if ($this->form_validation->run())
        {
            // Prepare the account data.
            $data = [
                'email' => $this->input->post('email'),
                'password' => encrypt_password($this->input->post('password')),
                'name' => $this->input->post('name'),
                'type' => 'parent',
                'time_created' => time(),
                'time_updated' => time()
            ];
            
            // Add to the database.
            $this->users_model->add_user($data);
            
            // Set flashdata.
            $this->session->set_flashdata('register_success', true);
            
            // Redirect to the login page.
            redirect('login');
        }
        else
        {
            // Display the register page again.
            $this->index();
        }
    }
}