<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Login controller
 *
 * @package     MIT3 BKVK
 * @subpackage  Controllers
 * @author      Roel Larik
 */

class Login extends CI_Controller {
    
    /**
     * Class's constructor.
     * 
     */
    public function __construct()
    {
        // Extend the CI_Controller constructor.
        parent::__construct();
        
        // Load the required libraries.
        $this->load->library([
            'form_validation'
        ]);
        
        // Load the models needed.
        $this->load->model([
            'users_model'
        ]);
    }
    
    /**
     * Default login view.
     * 
     * @return view
     */
    public function index()
    {
        $this->template_lib->render_partial('login');
    }
    
    /**
     * Processing the login request.
     * 
     * @return view
     */
    public function process()
    {
        // Set validation rules.
        $this->form_validation->set_rules('email', 'E-mail adres', 'required|callback_account_check[' . $this->input->post('password') . ']', [
            'required' => 'Vul uw e-mail adres in.'
        ]);
        $this->form_validation->set_rules('password', 'Wachtwoord', 'required', [
            'required' => 'Vul uw wachtwoord in.'
        ]);
        
        // Custom error delimiter.
        $this->form_validation->set_error_delimiters('<li>', '</li>');
        
        // Perform validation!
        if ($this->form_validation->run())
        {
			$user_data = array(
				'userId'  => $this->users_model->get_user_id($this->input->post('email')),
				'password' => encrypt_password($this->input->post('password')),
				'type' => $this->users_model->get_user_type($this->input->post('email'))
			);

			$this->session->set_userdata($user_data);
			
			redirect('dashboard');
        }
        else
        {
            // Display the login page again.
            $this->index();
        }
    }
    
    /**
     * Method to check whether the entered credentials 
     * are valid.
     * 
     * @param string $email
     * @param string $password
     * @return boolean
     */
    public function account_check($email = '', $password = '')
    {
        if ( ! empty($email) && ! empty($password))
        {
            if ($this->users_model->is_user($email, encrypt_password($password)))
            {
                return true;
            }
            else
            {
                $this->form_validation->set_message('account_check', 'Deze combinatie van e-mail adres en wachtwoord is bij ons niet bekend.');
                return false;
            }
        }
    }
}