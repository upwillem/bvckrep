<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Dashboard controller
 *
 * @package     MIT3 BKVK
 * @subpackage  Controllers
 * @author      
 */

class Dashboard extends CI_Controller {
	
	/**
	 * Class's constructor.
	 * 
	 */
	public function __construct()
	{
		// Extend the CI_Controller constructor.
		parent::__construct();
		
		// Load the models needed.
		$this->load->model([
			'users_model'
		]);
	}
	
	/**
	* Default dashboard view.
	* 
	* @return view
	*/
	public function index()
	{
		if($this->session->userId === null) redirect('login');
		
		$username = $this->users_model->get_user_name($this->session->userId);
		
		$data['name'] = $username;
		$data['type'] = $this->session->type;
		$this->template_lib->render('dashboard', $data);
	}
}