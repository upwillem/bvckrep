<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Security helper
 *
 * @package     MIT3 BVK
 * @subpackage  Helpers
 * @author      Roel Larik
 */

/**
 * Encrypts a password with salts.
 * 
 * @param string $password
 * @return string
 */
function encrypt_password($password = '')
{
    // Get the CodeIgniter instance.
    $CI =& get_instance();
    
    // Create the password string with SALTs.
    $password = $CI->config->item('salt_prefix') . $password . $CI->config->item('salt_suffix');
    
    // Return the hashed string.
    return hash('sha512', $password);
}