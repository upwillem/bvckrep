<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------
| Password salt
| -------------------------------------------------------------------
| Definition of the static salt used in the passwords throughout
| the application. Consists of a prefix and suffix.
|
*/
$config['salt_prefix'] = 'BCVK2015zuyd';
$config['salt_suffix'] = 'mit3blok3';